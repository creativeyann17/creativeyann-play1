#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    //Q_PROPERTY(QColor c READ color WRITE setColor)
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
public slots:
    void showText();
    void hide();
private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
