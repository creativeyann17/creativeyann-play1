#include <QPropertyAnimation>
#include <QTimer>
#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->label->setVisible(false);
}

void MainWindow::showText(){
    QString t;
    t.append(QString::number(ui->horizontalSlider->value()));
    t.append(" ");
    t.append(ui->lineEdit->text());
    ui->label->setText(t);
    ui->label->setVisible(true);

    static QTimer *timer = new QTimer(this);
    timer->stop();
    connect(timer, SIGNAL(timeout()),this, SLOT(hide()));
    timer->start(3000);

}

void MainWindow::hide(){
    ui->label->setVisible(false);

}

MainWindow::~MainWindow()
{
    delete ui;
}
