time ./PrimeIterative.exe ; time ./PrimeParallel.exe
