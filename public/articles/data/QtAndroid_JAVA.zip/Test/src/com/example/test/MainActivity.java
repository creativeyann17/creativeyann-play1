package com.example.test;

import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {
	
	private Context context;
	private Button button1;
	private TextView field1;
	private SeekBar bar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.context=this;
        this.bar=(SeekBar)findViewById(R.id.seekBar1);
        this.field1=(TextView)findViewById(R.id.editText1);
        this.button1=(Button)findViewById(R.id.button1);
        this.button1.setOnClickListener(this);
    }

    public void onClick(View v) {
    	if(v.equals(button1)){
    		showToast(field1.getText().toString());
    	}
    }
    
    private void showToast(String text) {
		Toast t=Toast.makeText(context, bar.getProgress()+" "+text, Toast.LENGTH_LONG);
		t.show();
	}

    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return false;
    }
    
}
