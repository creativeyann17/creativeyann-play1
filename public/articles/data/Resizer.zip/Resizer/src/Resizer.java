import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;

import javax.imageio.ImageIO;

public class Resizer extends RecursiveTask<Integer>{
	
	private static final long serialVersionUID = 1L;

	public static final int THREADS = Runtime.getRuntime().availableProcessors();
	public static final int THRESHOLD = 1;
	
	private int width,height,start,end;
	private File[] list;
	
	public Resizer(File[] list,int width,int height){
		this.list=list;
		this.width=width;
		this.height=height;
		this.start=0;
		this.end=list.length;
	}
	
	public Resizer(File[] list,int width,int height,int start,int end){
		this.list=list;
		this.width=width;
		this.height=height;
		this.start=start;
		this.end=end;
	} 

	private static BufferedImage resizeImage(BufferedImage originalImage,int width, int height) {
		int type = originalImage.getType() == 0 ? BufferedImage.TYPE_INT_ARGB : originalImage.getType();
		BufferedImage resizedImage = new BufferedImage(width, height, type);
		Graphics2D g = resizedImage.createGraphics();
		g.drawImage(originalImage, 0, 0, width, height, null);
		g.dispose();
		return resizedImage;
	}
	
	private static BufferedImage loadImage(File file) throws Exception{
		return ImageIO.read(file);
	}
	
	private static void saveImage(BufferedImage image,File file) throws IOException{
		ImageIO.write(image,"jpg",file); 
	}
	
	private static void cleanFolder(String folder){
		File out=new File(folder);
		for(File file:out.listFiles()){
			file.delete();
		}
	}
	
	public static void main(String[]args){
		try{
			System.out.println("Clean output folder...");
			cleanFolder("output");
			System.out.println("Start resizer with "+THREADS+" threads...");
			long start=System.currentTimeMillis();
			File in=new File("input");
			Resizer fb = new Resizer(in.listFiles(),1024,768);
			ForkJoinPool pool = new ForkJoinPool(THREADS);
			int count=pool.invoke(fb);
			System.out.println("Done: "+count+"/"+in.list().length+" in "+(System.currentTimeMillis()-start)+" ms");
		}catch(Exception e){
			e.printStackTrace();
		}
		/*SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				ResizerFrame frame=new ResizerFrame();
				frame.setVisible(true);
			}
		});*/
	}

	protected Integer compute() {
		int length=(end-start);
		int count=0;
		if(length<=THRESHOLD){
			for(int i=start;i<end;++i){
				File file=list[i];
				try{
					//System.out.println("Memory: "+MemoryManager.getUsed(MemoryManager.MB)+"/"+MemoryManager.getTotal(MemoryManager.MB));
					BufferedImage image=loadImage(file);
					BufferedImage image2=resizeImage(image,width, height);		
					saveImage(image2,new File("output/"+i+".jpg"));
					//System.out.println("Success to resize image: "+file.getName());
					count++;
				}catch(Exception e){
					System.out.println("Failed to resize image: "+file.getName()+ " reason: "+e.getMessage());
				}
			}
		}else{
			int mid = start + (length >> 1);
			Resizer m1=new Resizer(list,width,height,start,mid);
			Resizer m2=new Resizer(list,width,height,mid,end);
			m1.fork();//m2.fork();
			count=(m2.compute()+m1.join());
		}
		return count;
	}

}

