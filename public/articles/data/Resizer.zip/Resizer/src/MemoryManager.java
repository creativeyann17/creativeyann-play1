
public final class MemoryManager {
	
	public static final int KB = 1024*1024;
	public static final int MB = 1024*1024;
	
	private static final Runtime runtime = Runtime.getRuntime();
	
	private MemoryManager(){
		
	}
	
	private static long formatMemory(long value,int...format){
		if(format.length>0)
			value/=format[0];
		return value;
	}
	
	public static long getUsed(int...format){
		return formatMemory((runtime.totalMemory() - runtime.freeMemory()),format);
	}
	
	public static long getFree(int...format){
		return formatMemory(runtime.freeMemory(),format);
	}
	
	public static long getTotal(int...format){
		return formatMemory(runtime.totalMemory(),format);
	}
}
