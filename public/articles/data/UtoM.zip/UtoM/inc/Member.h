#ifndef _MEMBER_H
#define _MEMBER_H

#include "Entity.h"

class Member:public Entity{
public:
	explicit Member(const std::string &,const std::string &);
	virtual ~Member();
	const std::string & getType() const;
	void accept(EntityVisitor * const) const;
private:
	std::string m_Type;
};

#endif
