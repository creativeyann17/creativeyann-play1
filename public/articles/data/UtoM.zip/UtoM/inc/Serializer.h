#ifndef _SERIALIZER_H
#define _SERIALIZER_H

#include "Parser.h"
#include "EntityVisitor.h"
#include <string>

class Serializer:public EntityVisitor{
friend class SerializerFactory;
public:
	explicit Serializer();
	virtual ~Serializer();
	void serialize(const Parser::TClassList &) ;
	virtual void visitClass(const Class * const) = 0;
	virtual void visitMember(const Member * const) = 0;
	virtual std::string toString() const = 0;
private:
	virtual void init() = 0;
};

#endif
