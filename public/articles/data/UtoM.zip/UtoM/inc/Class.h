#ifndef _CLASS_H
#define _CLASS_H

#include "Entity.h"
#include <list>

class Member;
class Class:public Entity{
public:
	typedef std::list<Member*> TMemberList;
	explicit Class(const std::string &);
	virtual ~Class();
	void addMember(Member*const);
	const TMemberList & getMembers() const;
	void accept(EntityVisitor * const) const;
private:
	TMemberList m_Members;
};

#endif
