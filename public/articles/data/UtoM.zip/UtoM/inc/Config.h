#ifndef _CONFIG_H
#define _CONFIG_H

#ifndef NO_ERROR
#define NO_ERROR 0
#endif

#ifdef WIN32
	#define UTOM_PRG_NAME "UtoM.exe"
#else
	#define UTOM_PRG_NAME "UtoM"
#endif

#ifndef UTOM_SERIALIZERS
#define UTOM_SERIALIZERS "C/C++/JAVA"
#endif

#ifndef UTOM_VERSION
#define UTOM_VERSION "0.01"
#endif

#endif
