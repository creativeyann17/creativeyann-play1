#ifndef _VIOLET_UML_PARSER_H
#define _VIOLET_UML_PARSER_H

#include "Parser.h"

class VioletUMLParser:public Parser{
friend class ParserFactory;
public:
	virtual ~VioletUMLParser();
	const TClassList & parse(const std::string &);
	bool isCompatible(const std::string &);
	void visitClass(const Class * const);
	void visitMember(const Member * const);
	std::string toString() const;
private:
	explicit VioletUMLParser();
};

#endif
