#ifndef _ENTITY_H
#define _ENTITY_H

#include "EntityVisitor.h"
#include <string>

class Entity{
public:
	explicit Entity(const std::string &);
	virtual ~Entity();
	const std::string & getName() const;
	virtual void accept(EntityVisitor * const) const = 0;
private:
	std::string m_Name;
};

#endif
