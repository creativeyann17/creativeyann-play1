#ifndef _PARSER_FACTORY_H
#define _PARSER_FACTORY_H

#include "Parser.h"
#include <string>
#include <list>

class Parser;
class ParserFactory{
public:
	typedef std::list<Parser *> TParserList;
	virtual ~ParserFactory();
	static const TParserList & getParsers();
private:
	static ParserFactory * const getInstance();
	static ParserFactory * m_Instance;
	explicit ParserFactory();
	TParserList m_Parsers;
};

#endif
