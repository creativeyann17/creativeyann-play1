#ifndef _VIOLET_UML_PARSER_H
#define _VIOLET_UML_PARSER_H

#include "Serializer.h"

class CSerializer:public Serializer{
friend class SerializerFactory;
public:
	virtual ~CSerializer();
	void init();
	void visitClass(const Class * const);
	void visitMember(const Member * const);
	std::string toString() const ;
private:
	explicit CSerializer();
};

#endif
