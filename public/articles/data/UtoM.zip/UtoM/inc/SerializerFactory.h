#ifndef _SERIALIZER_FACTORY_H
#define _SERIALIZER_FACTORY_H

#include "Serializer.h"
#include <string>
#include <map>

class Serializer;
class SerializerFactory{
public:
	typedef std::map<std::string,Serializer *> TSerializerMap;
	virtual ~SerializerFactory();
	static Serializer * const getSerializer(const std::string &);
private:
	static SerializerFactory * const getInstance();
	static SerializerFactory * m_Instance;
	explicit SerializerFactory();
	TSerializerMap m_Serializers;
};

#endif
