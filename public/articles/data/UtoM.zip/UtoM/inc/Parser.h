#ifndef _PARSER_H
#define _PARSER_H

#include "EntityVisitor.h"
#include <list>
#include <string>

class Parser:public EntityVisitor{
friend class ParserFactory;
public:
	typedef std::list<Class *> TClassList;
	explicit Parser();
	virtual ~Parser();
	virtual const TClassList & parse(const std::string &) = 0;
	virtual bool isCompatible(const std::string &) = 0;
	virtual void visitClass(const Class * const) = 0;
	virtual void visitMember(const Member * const) = 0;
	virtual std::string toString() const = 0;
private:
	void init();
protected:
	TClassList m_ClassList;
};

#endif
