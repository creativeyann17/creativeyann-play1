#ifndef _ENTITY_VISITOR_H
#define _ENTITY_VISITOR_H

class Class;
class Member;
class EntityVisitor{
public:
	EntityVisitor();
	virtual ~EntityVisitor();
	virtual void visitClass(const Class * const) = 0;
	virtual void visitMember(const Member * const) = 0;
};

#endif
