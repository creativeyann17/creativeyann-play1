#include "Serializer.h"
#include "Class.h"

Serializer::Serializer()
{

}

Serializer::~Serializer()
{

}

void Serializer::serialize(const Parser::TClassList & _ClassList)
{
	Parser::TClassList::const_iterator l_It;
	for(l_It=_ClassList.begin();l_It!=_ClassList.end();++l_It){
		Class * l_Class=(*l_It);
		l_Class->accept(this);
	}
}
