#include "Entity.h"

Entity::Entity(const std::string & _Name):
m_Name(_Name)
{

}

Entity::~Entity()
{

}

const std::string & Entity::getName() const
{
	return m_Name;
}
