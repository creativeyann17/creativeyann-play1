#include "Config.h"
#include "ParserFactory.h"
#include "SerializerFactory.h"

extern "C"{
	#include <stdio.h>
	#include <string.h>
}

int main(int argc,char * argv[])
{
	if(argc==2){
		if(strstr(argv[1],"--version")){
			::printf("%s %s\n",UTOM_PRG_NAME,UTOM_VERSION);
			return NO_ERROR;
		}
	}
	
	if(argc<3){
		::printf("Syntax: %s <input_file> [%s]\n",UTOM_PRG_NAME,UTOM_SERIALIZERS);
		return NO_ERROR;
	}
	
	std::string l_InputFile(argv[1]);
	::printf("Input file: %s\n",l_InputFile.c_str());
	
	Parser * l_ParserOK=NULL;
	const ParserFactory::TParserList & l_Parsers = ParserFactory::getParsers();
	ParserFactory::TParserList::const_iterator l_ParserIt;
	for(l_ParserIt=l_Parsers.begin();l_ParserIt!=l_Parsers.end();++l_ParserIt){
		Parser * const l_Parser=(*l_ParserIt);
		if(l_Parser->isCompatible(l_InputFile)){
			l_ParserOK=l_Parser;
			break;
		}
	}
	
	if(!l_ParserOK){
		::printf("No compatible UML Parser found for: %s\n",l_InputFile.c_str());
		return NO_ERROR;
	}
	
	::printf("Compatible UML Parser: %s\n",l_ParserOK->toString().c_str());
	
	std::string l_Output(argv[2]);
	::printf("Output langage: %s\n",l_Output.c_str());
	
	Serializer * l_SerializerOK=SerializerFactory::getSerializer(l_Output);
	
	if(!l_SerializerOK){
		::printf("No compatible Serializer found for: %s\n",l_Output.c_str());
		return NO_ERROR;
	}
	
	::printf("Compatible Serializer: %s\n",l_SerializerOK->toString().c_str());
	
		
	return NO_ERROR;
}
