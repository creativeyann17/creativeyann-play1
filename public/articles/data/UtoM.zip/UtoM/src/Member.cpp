#include "Member.h"

Member::Member(const std::string & _Name,const std::string & _Type):
Entity(_Name),
m_Type(_Type)
{

}

Member::~Member()
{

}

const std::string & Member::getType() const
{
	return m_Type;
}

void Member::accept(EntityVisitor * const _Visitor) const
{
	_Visitor->visitMember(this);
}	
