#include "EntityVisitor.h"

EntityVisitor::EntityVisitor()
{

}

EntityVisitor::~EntityVisitor()
{

}
