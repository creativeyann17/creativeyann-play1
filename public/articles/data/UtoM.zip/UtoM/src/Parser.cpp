#include "Parser.h"

Parser::Parser()
{

}

Parser::~Parser()
{

}

void Parser::init(){
	m_ClassList.clear();
}
