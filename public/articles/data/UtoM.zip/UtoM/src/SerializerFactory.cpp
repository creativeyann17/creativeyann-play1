#include "SerializerFactory.h"
#include "Serializer.h"
#include "CSerializer.h"

SerializerFactory * SerializerFactory::m_Instance=NULL;

SerializerFactory::SerializerFactory()
{
	m_Serializers["C"]=new CSerializer();
	m_Serializers["CPP"]=NULL;
	m_Serializers["JAVA"]=NULL;
}

SerializerFactory::~SerializerFactory()
{
	TSerializerMap::iterator l_It;
	for(l_It=m_Serializers.begin();l_It!=m_Serializers.end();++l_It){
		Serializer * l_Serializer=l_It->second;
		if(l_Serializer){
			delete l_Serializer;
			l_Serializer=NULL;
		}
	}
	if(m_Instance){
		delete m_Instance;
		m_Instance=NULL;
	}
}

Serializer * const SerializerFactory::getSerializer(const std::string & _Type)
{
	Serializer* const l_Serializer=getInstance()->m_Serializers[_Type];
	if(l_Serializer)l_Serializer->init();
	return l_Serializer;
}

SerializerFactory * const SerializerFactory::getInstance()
{
	if(m_Instance==NULL)m_Instance=new SerializerFactory();
	return m_Instance;
}
