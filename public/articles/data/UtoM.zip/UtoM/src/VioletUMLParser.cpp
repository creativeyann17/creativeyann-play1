#include "VioletUMLParser.h"

VioletUMLParser::VioletUMLParser()
{

}

VioletUMLParser::~VioletUMLParser()
{

}

const Parser::TClassList & VioletUMLParser::parse(const std::string & _FileName)
{
	return m_ClassList;
}

bool VioletUMLParser::isCompatible(const std::string & _FileName)
{
	return true;
}

void VioletUMLParser::visitClass(const Class * const _Class)
{

}

void VioletUMLParser::visitMember(const Member * const _Member)
{

}

std::string VioletUMLParser::toString() const
{
	return "Violet UML Parser V0.01";
}
