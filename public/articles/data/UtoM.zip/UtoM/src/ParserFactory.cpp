#include "ParserFactory.h"
#include "VioletUMLParser.h"

ParserFactory * ParserFactory::m_Instance=NULL;

ParserFactory::ParserFactory()
{
	m_Parsers.push_back(new VioletUMLParser());
}

ParserFactory::~ParserFactory()
{
	TParserList::iterator l_It;
	for(l_It=m_Parsers.begin();l_It!=m_Parsers.end();++l_It){
		Parser * l_Parser=(*l_It);
		if(l_Parser){
			delete l_Parser;
			l_Parser=NULL;
		}
	}
	if(m_Instance){
		delete m_Instance;
		m_Instance=NULL;
	}
}

const ParserFactory::TParserList & ParserFactory::getParsers()
{
	return getInstance()->m_Parsers;
}

ParserFactory * const ParserFactory::getInstance()
{
	if(m_Instance==NULL)m_Instance=new ParserFactory();
	return m_Instance;
}
