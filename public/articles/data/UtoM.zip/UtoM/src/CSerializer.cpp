#include "CSerializer.h"

CSerializer::CSerializer()
{

}

CSerializer::~CSerializer()
{

}

void CSerializer::init() 
{
	
}

void CSerializer::visitClass(const Class * const _Class)
{

}

void CSerializer::visitMember(const Member * const _Member)
{

}

std::string CSerializer::toString() const
{
	return "C Serializer V0.01";
}
