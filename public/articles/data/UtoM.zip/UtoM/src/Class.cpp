#include "Class.h"

Class::Class(const std::string & _Name):
Entity(_Name)
{

}

Class::~Class()
{

}

void Class::addMember(Member * const _Member)
{
	m_Members.push_back(_Member);
}

const Class::TMemberList & Class::getMembers() const
{
	return m_Members;
}

void Class::accept(EntityVisitor * const _Visitor) const
{
	_Visitor->visitClass(this);
}	
