#ifndef _WHEEL_H
#define _WHEEL_H

class Wheel{
public:
  Wheel(const unsigned int &);
  const unsigned int & getSize() const;
protected:
  unsigned int m_Size;

};

#endif



