#ifndef _SERVO_WHEEL_H
#define _SERVO_WHEEL_H

#include <Servo.h>
#include "Wheel.h"

class ServoWheel:
public Wheel{
public:
  ServoWheel(const unsigned int &,const Servo &,const unsigned int &,const unsigned int &,const unsigned int&,const unsigned int&);
  void setLeft();
  void setRight();
  void setMiddle();
  void set(const unsigned int &);
private:
  void wait(const unsigned int &,const unsigned int&);
private:
  Servo m_Servo;
  unsigned int m_Middle;
  unsigned int m_Left;
  unsigned int m_Right;
  unsigned int m_Time;
};

#endif




