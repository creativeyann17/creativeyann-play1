#ifndef _ROBOT_H
#define _ROBOT_H

#include "RobotConst.h"
#include "ServoWheel.h"
#include "MotorWheel.h"

class Robot{
public:
  Robot(const Servo &,const Servo &,const Servo &);
  void init();
  void run();
private:
  void advance(const double &);
  void rotateRight(const double &);
  void rotateLeft(const double &);
private:
  ServoWheel m_WheelTop;
  MotorWheel m_WheelLeft;
  MotorWheel m_WheelRight;
  double m_Width;
  double m_Perimeter;
  double m_DistancePerAngle;
};

#endif



