#ifndef _MOTOR_WHEEL_H
#define _MOTOR_WHEEL_H

#include <Servo.h>
#include "MotorWheel.h"
#include "Wheel.h"

class MotorWheel: public Wheel{
public:
  MotorWheel(const unsigned int &,const Servo &,const unsigned int & , const unsigned int &,const unsigned int &,const MotorWheel&);
  double front(const double&);
  double back(const double&);
  void stop();
private:
  double move(const unsigned int&,const double &);
private:
  Servo m_Servo;
  unsigned int m_Front;
  unsigned int m_Back;
  double m_RPM;
  double m_DistancePerMs;
};
#endif
