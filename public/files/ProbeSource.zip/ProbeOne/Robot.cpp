#include <WProgram.h>
#include "Robot.h"

Robot::Robot(const Servo & _ServoTop,const Servo & _ServoLeft,const Servo & _ServoRight):
m_WheelTop(WHEEL_SIZE,_ServoTop,WHEEL_TOP_MIDDLE,WHEEL_TOP_LEFT,WHEEL_TOP_RIGHT,WHEEL_TOP_TIME),
m_WheelLeft(WHEEL_SIZE,_ServoLeft,WHEEL_LEFT_FRONT,WHEEL_LEFT_BACK,SERVO_RPM_LEFT,m_WheelRight),
m_WheelRight(WHEEL_SIZE,_ServoRight,WHEEL_RIGHT_FRONT,WHEEL_RIGHT_BACK,SERVO_RPM_RIGHT,m_WheelLeft),
m_DistancePerAngle(ROBOT_WIDTH*3.14/360)
{

}

void Robot::init(){
  m_WheelTop.setMiddle(); 
}

void Robot::run(){
  advance(40);
  rotateRight(90);
  advance(40);
  rotateRight(90);
  advance(40);
  rotateRight(90);
  advance(40);
  rotateRight(90);
}

void Robot::rotateRight(const double & _Angle){
  m_WheelTop.setRight();
  unsigned int l_WaitLeft=m_WheelLeft.front(_Angle*m_DistancePerAngle);
  unsigned int l_WaitRight=m_WheelRight.back(_Angle*m_DistancePerAngle);
  unsigned int l_Wait=(l_WaitLeft>l_WaitRight)?l_WaitLeft:l_WaitRight;
  ::delay(l_Wait);
  m_WheelLeft.stop();
  m_WheelRight.stop();
  m_WheelTop.setMiddle();
}

void Robot::rotateLeft(const double & _Angle){
  m_WheelTop.setLeft();
  unsigned int l_WaitLeft=m_WheelLeft.back(_Angle*m_DistancePerAngle);
  unsigned int l_WaitRight=m_WheelRight.front(_Angle*m_DistancePerAngle);
  unsigned int l_Wait=(l_WaitLeft>l_WaitRight)?l_WaitLeft:l_WaitRight;
  ::delay(l_Wait);
  m_WheelLeft.stop();
  m_WheelRight.stop();
  m_WheelTop.setMiddle();
}

void Robot::advance(const double & _Distance){
  unsigned int l_WaitLeft=m_WheelLeft.front(_Distance);
  unsigned int l_WaitRight=m_WheelRight.front(_Distance);
  unsigned int l_Wait=(l_WaitLeft>l_WaitRight)?l_WaitLeft:l_WaitRight;
  ::delay(l_Wait);
  m_WheelLeft.stop();
  m_WheelRight.stop();
}




