#include <WProgram.h>
#include "MotorWheel.h"

MotorWheel::MotorWheel(const unsigned int & _Size,const Servo & _Servo,const unsigned int & _Front,const unsigned int & _Back,const unsigned int & _RPM,const MotorWheel & _SisterWheel):
Wheel(_Size),
m_Servo(_Servo),
m_Front(_Front),
m_Back(_Back),
m_RPM(_RPM),
m_DistancePerMs(((m_RPM/60)/1000)*((m_Size*3.14)))
{
  
}

void MotorWheel::stop(){
   m_Servo.write(1500);
}

double MotorWheel::move(const unsigned int & _Direction,const double & _Distance){
  m_Servo.write(_Direction);
  return _Distance/m_DistancePerMs;
}

double MotorWheel::front(const double & _Distance){
  return move(m_Front,_Distance);
}

double MotorWheel::back(const double & _Distance){
  return move(m_Back,_Distance);
}




