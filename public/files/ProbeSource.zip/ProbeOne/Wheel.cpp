#include "Wheel.h"

Wheel::Wheel(const unsigned int & _Size):
m_Size(_Size)
{

}

const unsigned int & Wheel::getSize() const{
  return m_Size;
}

