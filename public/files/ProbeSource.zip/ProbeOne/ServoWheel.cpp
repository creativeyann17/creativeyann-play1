#include <WProgram.h>
#include "ServoWheel.h"

ServoWheel::ServoWheel(const unsigned int & _Size, const Servo & _Servo,const unsigned int& _Middle,const unsigned int& _Left,const unsigned int& _Right,const unsigned int& _Time):
Wheel(_Size),
m_Servo(_Servo),
m_Middle(_Middle),
m_Left(_Left),
m_Right(_Right),
m_Time(_Time)
{
  
}

void ServoWheel::setLeft()
{
  set(m_Left);
}

void ServoWheel::setRight()
{
  set(m_Right);
}

void ServoWheel::setMiddle()
{
  set(m_Middle);
}

void ServoWheel::wait(const unsigned int & _AngleStart,const unsigned int  & _AngleEnd)
{
    delay(m_Time*abs((int)(_AngleStart-_AngleEnd)));
}

void ServoWheel::set(const unsigned int  & _Angle)
{
  unsigned int l_Angle=m_Servo.read();
  m_Servo.write(_Angle);
  wait(l_Angle,_Angle);
}



