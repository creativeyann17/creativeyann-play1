package controllers;

import play.db.jpa.NoTransaction;
import play.mvc.Controller;
import play.mvc.Http.Header;

public class MobileDevice extends Controller{

	@NoTransaction
	public static void index(){
		render();
	}
	
	@NoTransaction
	public static void selectMobileDevice(String useMobile){
		boolean useMobileDevice=(useMobile!=null && useMobile.length()>0);
		session.put("useMobileDevice", useMobileDevice);
		redirect("/"); // Application.index() don'st work;
	}
	
	public static boolean isMobileDevice(Header userAgent){
		if(userAgent==null)return false;
		for(String value:userAgent.values){
			if(value.toLowerCase().contains("android")){
				return true;
			}else if(value.toLowerCase().contains("blackberry")){
				return true;
			}else if(value.toLowerCase().contains("iemobile")){
				return true;
			}else if(value.toLowerCase().contains("ipad")){
				return true;
			}else if(value.toLowerCase().contains("iphone")){
				return true;
			}
		}
		return false;
	}
}
