package controllers;

import play.mvc.Before;
import play.mvc.Controller;

public class Secure extends Controller{
	
	@Before
	public static void checkAdmin(){
		if(session.get("login")==null){
			Application.admin(null,null);
		}
	}

}
