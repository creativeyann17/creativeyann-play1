package controllers;

import java.util.Date;

import models.entities.Message;
import play.cache.Cache;
import play.db.jpa.NoTransaction;
import play.i18n.Lang;
import play.i18n.Messages;
import play.mvc.Controller;
import play.mvc.Scope.Session;

public class Settings extends Controller{

	@NoTransaction
	public static void setLanguage(String value){
    	if(validation.required(value).error==null){
    		Lang.change(value);
    	}
    	Application.redirectCallingPage();
    }
	
	public static void postMessage(String name,String email,String message){
		checkAuthenticity();
		String sessionIDContact=session.getId()+"_contact";
		Object tmp=Cache.get(sessionIDContact);
		
		if(tmp==null){
			Message msg=new Message(name,email,new Date(),message,request.remoteAddress);
			msg.save();
			
			Cache.set(sessionIDContact,true,"1min");
			
			Application.contact(Messages.get("contactMessageSent"),"lightgreen");
			
		}else{
			flash.put("name", name);flash.put("email", email);flash.put("message", message);
			Application.contact(Messages.get("contactMessageRefused"," < 1"),"rgb(240,100,100)");
		}
		
	}
}
