package controllers;

import play.*;
import play.db.jpa.NoTransaction;
import play.db.jpa.Transactional;
import play.i18n.Messages;
import play.mvc.*;
import play.mvc.Http.Header;
import play.mvc.Scope.Session;

import java.net.URL;
import java.util.*;

import models.*;
import models.entities.Article;
import models.jobs.Bootstrap;
import models.pages.AboutPage;
import models.pages.ApplicationPage;
import models.pages.ContactPage;

public class Application extends Controller {
	
	@Before
	public static void checkMobileDevice(){
		if(!session.contains("useMobileDevice")){
			if(MobileDevice.isMobileDevice(request.headers.get("user-agent"))){
				MobileDevice.index();
			}else{
				session.put("useMobileDevice",false);
			}	
		}
	}

	@NoTransaction
	public static void logout(){
		session.remove("login");
		Application.admin(null,null);
	}
	
	@NoTransaction
	public static void login(String login,String password){
		checkAuthenticity();
		String goodLogin=Play.configuration.getProperty("application.login");
		String goodPwd=Play.configuration.getProperty("application.pwd");
		if(login.equals(goodLogin) && password.equals(goodPwd)){
			session.put("login", true);
			Administration.index();
		}else{
			Application.admin(login,"Invalid login and/or password");
		}
	}

	@NoTransaction
    public static void index() {
		if(!session.contains("newSession")){
			session.put("newSession", request.remoteAddress);
			//System.out.println(new Date()+ " new session: "+request.remoteAddress);
		}
		ApplicationPage page=new ApplicationPage(session);
        render(page);
    }
	
	@Transactional(readOnly=true)
    public static void articles(Long id) {
		ApplicationPage page=new ApplicationPage(session);
		List<Article> articles=null;
		if(id==null){
			articles=Article.find("visible= true order by date desc").fetch();
			renderArgs.put("articles", articles);
		}else{
			Article article=Article.findById(id);
			renderArgs.put("article", article);
		}
        render(page);
    }
	
	@NoTransaction
    public static void wip() {
		ApplicationPage page=new ApplicationPage(session);
        render(page);
    }
	
	@NoTransaction
    public static void contact(String status,String statusColor) {
		ApplicationPage page=new ApplicationPage(session);
		
		//ContactPage contact=new ContactPage();
		/*String[] antiSpam=contact.getAntiSpamString();
		renderArgs.put("antiSpam",antiSpam[0]);
		renderArgs.put("antiSpamValue",antiSpam[1]);*/
		
		render(page,status,statusColor);
	}
	
	@NoTransaction
    public static void about() {
		ApplicationPage page=new ApplicationPage(session);
		AboutPage about=new AboutPage();
		
		renderArgs.put("appVersion", Bootstrap.APP_VERSION);
		renderArgs.put("appLastUpdate", Bootstrap.LAST_UPDATE);
		renderArgs.put("hwDetails", Bootstrap.HW_DETAILS);
		renderArgs.put("jreDetails", Bootstrap.JRE_DETAILS);
		renderArgs.put("kernelDetails", Bootstrap.KERNEL_DETAILS);
		renderArgs.put("osDetails", Bootstrap.OS_DETAILS);
		renderArgs.put("playFramework", Play.version);
		renderArgs.put("runtime", about.getRuntime());
		renderArgs.put("myAge", about.getMyAge());
		renderArgs.put("memory", about.getMemory());
		
        render(page);
    }
	
	@NoTransaction
	public static void admin(String login,String status){
		if(session.get("login")!=null){
			Administration.index();
		}
		ApplicationPage page=new ApplicationPage(session);
        render(page,login,status);
	}
	
	public static void redirectCallingPage(){
		try {
			Header refererHeader = Http.Request.current().headers.get("referer");
			if (refererHeader != null) {
				List<String> refererList = refererHeader.values;
				if (refererList != null) {
					String callingPageURL = refererList.get(0);
					if (callingPageURL != null && callingPageURL.length() > 0) {
						redirect(new URL(callingPageURL).getFile());
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		index();
	}

}