package controllers;

import models.pages.ApplicationPage;
import play.mvc.Controller;

public class Wip extends Controller{
	
	public static void creativeYann(){
		ApplicationPage page=new ApplicationPage(session);
        render(page);
	}
	
	public static void probe(){
		ApplicationPage page=new ApplicationPage(session);
        render(page);
	}
	
	public static void mud(){
		ApplicationPage page=new ApplicationPage(session);
        render(page);
	}

}
