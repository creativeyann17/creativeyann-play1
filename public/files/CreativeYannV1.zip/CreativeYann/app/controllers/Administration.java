package controllers;

import java.awt.Image;
import java.io.File;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import models.FileUtils;
import models.entities.Article;
import models.entities.Message;
import models.jobs.CameraJob;
import models.pages.ApplicationPage;
import play.Play;
import play.db.jpa.NoTransaction;
import play.db.jpa.Transactional;
import play.libs.F.Promise;
import play.mvc.Before;
import play.mvc.Controller;
import play.mvc.With;

@With(Secure.class)
public class Administration extends Controller{

	@NoTransaction
	public static void index(){
		ApplicationPage page=new ApplicationPage(session);
        render(page);
	}
	
	@Transactional(readOnly=true)
	public static void messages(){
		
		List<Message> msgs=Message.find("order by date desc").fetch();
		
		ApplicationPage page=new ApplicationPage(session);
        render(page,msgs);
	}
	
	public static void msgActions(){
		checkAuthenticity();
		Map<String, String[]>params=request.params.all();
		for(String key:params.keySet()){
			if(key.equals("remove")){
				String[] values=params.get(key);
				for(String value:values){
					Long id=Long.parseLong(value);
					Message.delete("id = ?", id);
				}
			}
		}
		messages();
	}
	
	@Transactional(readOnly=true)
	public static void articles(Long id){
		ApplicationPage page=new ApplicationPage(session);
		List<Article> articles=Article.find("order by date desc").fetch();
		if(id!=null){
			renderArgs.put("article", Article.findById(id));	
		}
		renderArgs.put("articles", articles);
		render(page);
	}

	@NoTransaction
	public static void camera(){
		renderArgs.put("cameraPicture", CameraJob.INSTANCE.getCameraPicture());
		renderArgs.put("cameraPosition", CameraJob.INSTANCE.getCameraPosition());
		ApplicationPage page=new ApplicationPage(session);
		render(page);
	}
	
	@NoTransaction
	public static void moveCamera(int position){
		checkAuthenticity();
		CameraJob job=CameraJob.INSTANCE;
		job.setPosition(position);
		Promise promise=job.now();
		await(promise);
		if(job.getLastException()!=null){
			flash("cameraException", job.getLastException());
		}
		camera();
	}
	
}
