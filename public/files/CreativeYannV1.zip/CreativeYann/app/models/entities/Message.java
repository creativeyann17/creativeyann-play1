package models.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import play.db.jpa.Model;

@Entity
@Table(name="MESSAGE")
public class Message extends Model {
	
	@Column(name="NAME",nullable=false,length=50)
	public String name;
	
	@Column(name="EMAIL",nullable=false,length=50)
	public String email;
	
	@Column(name="DATE",nullable=false)
	public Date date;

	@Column(name="MESSAGE",nullable=false,length=1024)
	public String message;
	
	@Column(name="IP",nullable=false,length=16)
	public String ip;

	public Message(String name,String email,Date date, String message, String ip) {
		super();
		this.name=name;
		this.email=email;
		this.date = date;
		this.message = message;
		this.ip = ip;
	}
	
}
