package models.pages;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

import controllers.Application;
import play.Play;
import play.i18n.Lang;
import play.mvc.Scope.Session;

public class ApplicationPage {
	
	// static supported languages map
	private static Map<String, String> supportedLanguages = null;
	
	private Session session;
	
	public ApplicationPage(Session session){
		this.session=session;
	}
	
	static{
		// linked array map because of unicity + keep put order
		supportedLanguages=new TreeMap<String, String>();
		supportedLanguages.put("en","English");
		supportedLanguages.put("fr","Français");
	}
	
	public static Map<String, String> getSupportedLanguages(){
		return supportedLanguages;
	}
	
	public String isLanguageSelected(String v){
		return (Lang.get().equals(v)?"selected":"");
	}
	
	public boolean useMobileDevice(){
		if(!session.contains("useMobileDevice"))
			return false;
		return session.get("useMobileDevice").equals("true");
	}

}
