package models.pages;

import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.Random;

import models.jobs.Bootstrap;
import play.Play;
import play.i18n.Messages;

public class AboutPage {
	
	private static final Calendar CALENDAR=Calendar.getInstance();

	public int getMyAge(){
		CALENDAR.setTime(new Date());
		return CALENDAR.get(Calendar.YEAR)-1987;
	}
	
	public static Date getRuntime(){
		Date diff=new Date(new Date().getTime() - (System.currentTimeMillis()-Bootstrap.START_TIME));
		return diff;
	}
	
	public static String getMemory(){
		Runtime runtime=Runtime.getRuntime();
		long used=runtime.totalMemory()-runtime.freeMemory();
		used=used/(1024*1024);
		long total=runtime.totalMemory()/(1024*1024);
		long max=runtime.maxMemory()/(1024*1024);
		return Messages.get("memoryConsumption",used,total,max);
	}
}
