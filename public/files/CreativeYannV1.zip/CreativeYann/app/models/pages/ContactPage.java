package models.pages;

import java.util.Random;

public class ContactPage {
	
	private static final Random RAND=new Random(System.currentTimeMillis());
	
	public String[] getAntiSpamString(){
		
		String [] res=new String[2];
		
		String operator="";
		
		int left=RAND.nextInt(10);
		int right=RAND.nextInt(10);
		
		int type=RAND.nextInt(4);
		
		int value=0;
		
		switch(type){
		case 0:
			operator="+";
			value=left+right;
			break;
		case 1:
			operator="-";
			value=left-right;
			break;
		case 2:
			operator="*";
			value=left*right;
			break;
		case 3:
			if(right>0 && left%right==0){
				operator="/";
				value=left/right;
			}else{
				operator="+";
				value=left+right;
			}
			break;
		}
		
		res[0]=left+" "+operator+" "+right;
		res[1]=""+value;
		
		return res;
	}

}
