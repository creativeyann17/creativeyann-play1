package models.jobs;

import java.io.File;
import java.util.Calendar;
import java.util.Date;

import play.Play;
import play.jobs.Job;
import play.jobs.OnApplicationStart;

@OnApplicationStart
public class Bootstrap extends Job{

	public static final long START_TIME = System.currentTimeMillis();
	
	public static final String APP_VERSION = Play.configuration.getProperty("application.version", "N/A");
	public static final String HW_DETAILS = Runtime.getRuntime().availableProcessors()+"xCPU "+String.format("%s", System.getProperty("os.arch"));
	public static final String OS_DETAILS = String.format("%s", System.getProperty("os.name"));
	public static final String KERNEL_DETAILS = String.format("%s", System.getProperty("os.version"));
	public static final String JRE_DETAILS = String.format("%s %s %s bits", System.getProperty("java.vendor"), System.getProperty("java.version"), System.getProperty("sun.arch.data.model"));
	public static final Date LAST_UPDATE = new Date(getLastUpdate(new File(Play.applicationPath+"/app"), 0));
	
	
	public void doJob() throws Exception{
		CameraJob.INSTANCE.setPosition(0);
		CameraJob.INSTANCE.now();
	}
	
	private static long getLastUpdate(File root,long minimal){
		long last=minimal;
		if(root.isDirectory()){
			for(File file:root.listFiles()){
				long ret=getLastUpdate(file, minimal);
				if(ret>last)last=ret;
			}
		}else{
			if(root.lastModified()>last){
				last=root.lastModified();
			}
		}
		return last;
	}
	
}
