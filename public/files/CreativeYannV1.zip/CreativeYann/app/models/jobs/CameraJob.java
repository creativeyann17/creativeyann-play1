package models.jobs;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.concurrent.locks.ReentrantLock;

import javax.imageio.ImageIO;

import play.Play;
import play.jobs.Job;

public class CameraJob extends Job{
	
	public static final CameraJob INSTANCE = new CameraJob();
	private ReentrantLock mutex=new ReentrantLock();
	
	private Exception lastException;
	
	private String cameraPicture="/public/images/cameraPicture.jpg";
	private int cameraPosition=0;
	
	private CameraJob(){
		// clean old camera pictures
		File folder=new File(Play.applicationPath+"/public/camera/");
		for(File file:folder.listFiles()){
			if(file.isFile() && file.getName().endsWith(".jpg")){
				file.delete();
			}
		}
	}
	
	public void setPosition(int position){
		this.cameraPosition=position;
	}
	
	public void doJob(){
		this.mutex.lock();
		
		try{
			// TODO move to position;
			lastException=null;
			
			// prepare temporary file
			File cameraFile=new File(Play.applicationPath+"/public/camera/"+System.currentTimeMillis()+".jpg");
			
			// take picture
			Runtime runtime=Runtime.getRuntime();
			String[]args=new String[]{"/bin/bash","-c","raspistill -t 1 -w 640 -h 480 -q 90 -e jpg -o "+cameraFile.getAbsolutePath()};
			Process process=runtime.exec(args);
			int ret=process.waitFor();
			if(ret!=0)throw new Exception("Camera command line returns: "+ret);
			
			// load image from picture file
			// Image image=ImageIO.read(cameraFile);
			
			// resize the image
			/*BufferedImage resizedImage = new BufferedImage(640, 480, BufferedImage.TYPE_INT_RGB);
			Graphics2D g = resizedImage.createGraphics();
			g.drawImage(image, 0, 0, resizedImage.getWidth(), resizedImage.getHeight(), null);
			g.dispose();*/
			
			// save the resized image into the tmp app folder 
			/*File outputfile = new File(Play.applicationPath+"/tmp/cameraPictureResized.jpg");
		    ImageIO.write(resizedImage, "jpg", outputfile);*/

		    // save the path to this picture
		    this.cameraPicture=cameraFile.getAbsolutePath().replace(Play.applicationPath.getAbsolutePath(),"");
		
		}catch(Exception e){
			this.lastException=e;
		}
		
		this.mutex.unlock();
	}
	
	public String getCameraPicture(){
		return cameraPicture;
	}
	
	public int getCameraPosition(){
		return cameraPosition;
	}

	public Exception getLastException() {
		return lastException;
	}

}
